import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Calendar, Clock, Sparkles, Star, Users, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <nav className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg flex items-center justify-center">
              <Star className="w-5 h-5 text-white" />
            </div>
            <span className="font-semibold text-xl text-gray-900">DentalCare</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={() => navigate('/login')}>
              Sign In
            </Button>
            <Button onClick={() => navigate('/login')} className="bg-blue-600 hover:bg-blue-700">
              Get Started
            </Button>
          </div>
        </div>
      </nav>

      <section className="container mx-auto px-4 pt-20 pb-16">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-medium">AI-Powered Scheduling</span>
          </div>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Your Smile Deserves the
            <span className="text-blue-600"> Best Care</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Experience modern dental care with intelligent appointment booking,
            personalized treatment plans, and seamless patient management.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-6 h-auto"
              onClick={() => navigate('/login')}
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Book with AI
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 py-6 h-auto border-blue-200 hover:bg-blue-50"
              onClick={() => navigate('/login')}
            >
              View Dashboard
            </Button>
          </div>
        </div>

        <div className="mt-20 grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <Card className="border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Calendar className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-gray-900">Smart Scheduling</h3>
              <p className="text-gray-600">
                AI-powered booking system finds the perfect time slot based on your preferences and availability.
              </p>
            </CardContent>
          </Card>

          <Card className="border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Clock className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-gray-900">Save Time</h3>
              <p className="text-gray-600">
                Book appointments in seconds, manage your visits, and get instant confirmations.
              </p>
            </CardContent>
          </Card>

          <Card className="border-blue-100 hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-gray-900">Secure & Private</h3>
              <p className="text-gray-600">
                Your health data is protected with enterprise-grade security and encryption.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="bg-blue-600 py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8 text-center text-white">
              <div>
                <div className="flex items-center justify-center mb-2">
                  <Users className="w-8 h-8" />
                </div>
                <div className="text-4xl font-bold mb-1">10,000+</div>
                <div className="text-blue-100">Happy Patients</div>
              </div>
              <div>
                <div className="flex items-center justify-center mb-2">
                  <Star className="w-8 h-8" />
                </div>
                <div className="text-4xl font-bold mb-1">4.9/5</div>
                <div className="text-blue-100">Patient Rating</div>
              </div>
              <div>
                <div className="flex items-center justify-center mb-2">
                  <Calendar className="w-8 h-8" />
                </div>
                <div className="text-4xl font-bold mb-1">50,000+</div>
                <div className="text-blue-100">Appointments</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            Ready to Transform Your Dental Experience?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Join thousands of patients who trust DentalCare for their oral health.
          </p>
          <Button
            size="lg"
            className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-6 h-auto"
            onClick={() => navigate('/login')}
          >
            <Sparkles className="w-5 h-5 mr-2" />
            Book Your First Appointment
          </Button>
        </div>
      </section>

      <footer className="border-t bg-gray-50 py-8">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>&copy; 2024 DentalCare. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
