export interface Database {
  public: {
    Tables: {
      patients: {
        Row: {
          id: string;
          full_name: string;
          email: string;
          phone: string | null;
          date_of_birth: string | null;
          address: string | null;
          emergency_contact: string | null;
          medical_history: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name: string;
          email: string;
          phone?: string | null;
          date_of_birth?: string | null;
          address?: string | null;
          emergency_contact?: string | null;
          medical_history?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          email?: string;
          phone?: string | null;
          date_of_birth?: string | null;
          address?: string | null;
          emergency_contact?: string | null;
          medical_history?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      appointments: {
        Row: {
          id: string;
          patient_id: string;
          appointment_date: string;
          duration_minutes: number;
          type: string;
          status: string;
          dentist_name: string;
          notes: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          patient_id: string;
          appointment_date: string;
          duration_minutes?: number;
          type: string;
          status?: string;
          dentist_name: string;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          patient_id?: string;
          appointment_date?: string;
          duration_minutes?: number;
          type?: string;
          status?: string;
          dentist_name?: string;
          notes?: string | null;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}
