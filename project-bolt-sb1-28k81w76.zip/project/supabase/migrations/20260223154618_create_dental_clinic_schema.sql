/*
  # Dental Clinic Management Schema

  ## Overview
  Complete database schema for dental clinic management system with patients and appointments.

  ## New Tables
  
  ### `patients`
  - `id` (uuid, primary key) - References auth.users
  - `full_name` (text) - Patient's full name
  - `email` (text) - Patient's email address
  - `phone` (text) - Contact phone number
  - `date_of_birth` (date) - Patient's date of birth
  - `address` (text) - Patient's address
  - `emergency_contact` (text) - Emergency contact information
  - `medical_history` (text) - Medical history notes
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Record update timestamp

  ### `appointments`
  - `id` (uuid, primary key) - Unique appointment identifier
  - `patient_id` (uuid) - References patients(id)
  - `appointment_date` (timestamptz) - Scheduled date and time
  - `duration_minutes` (integer) - Appointment duration
  - `type` (text) - Type of appointment (checkup, cleaning, etc.)
  - `status` (text) - Status (scheduled, completed, cancelled)
  - `dentist_name` (text) - Assigned dentist
  - `notes` (text) - Appointment notes
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Record update timestamp

  ## Security
  - Enable RLS on all tables
  - Patients can read and update their own data
  - Patients can read their own appointments
  - Admin users can perform all operations (to be implemented)
*/

-- Create patients table
CREATE TABLE IF NOT EXISTS patients (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  date_of_birth date,
  address text,
  emergency_contact text,
  medical_history text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create appointments table
CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id uuid NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
  appointment_date timestamptz NOT NULL,
  duration_minutes integer DEFAULT 30,
  type text NOT NULL,
  status text DEFAULT 'scheduled',
  dentist_name text NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

-- Patients policies
CREATE POLICY "Patients can read own data"
  ON patients FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Patients can update own data"
  ON patients FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert their own patient record"
  ON patients FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Appointments policies
CREATE POLICY "Patients can read own appointments"
  ON appointments FOR SELECT
  TO authenticated
  USING (patient_id IN (
    SELECT id FROM patients WHERE id = auth.uid()
  ));

CREATE POLICY "Patients can insert own appointments"
  ON appointments FOR INSERT
  TO authenticated
  WITH CHECK (patient_id IN (
    SELECT id FROM patients WHERE id = auth.uid()
  ));

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_appointments_patient_id ON appointments(patient_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(appointment_date);
CREATE INDEX IF NOT EXISTS idx_appointments_status ON appointments(status);
